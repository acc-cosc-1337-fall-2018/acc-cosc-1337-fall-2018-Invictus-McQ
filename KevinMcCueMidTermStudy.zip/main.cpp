#include <string>
#include "strings.h"
#include <iostream>
#include <vector>
#include "vector.h"
#include "receipt.h"
#include "shape.h"

using namespace::std;
	
int main()
{
string const test_s = "AGCTTTTCATTCTGACTGCAACGGGCAATATGTCTCTGTGTGGATTAAAAAAAGAGTGTCTGATAGCAGC";
vector<int> v = count_symbols(test_s);
for (auto s : v)
{
	cout << s << " ";
}
cout << endl << endl << endl << endl << endl;


//grades vector
vector<int> v2 = {100, 100, 90, 80, 80, 71, 67, 86, 87, 98, 87, 66, 76, 73, 71, 81, 91, 91, 90, 93};
display_grades(v2);




//str_by_reference()
string temp_str = "NAOMI";
cout << temp_str << endl;
str_by_reference(temp_str);
cout << endl;
//Why does the string change or not change?
//It changes because I set the referenced string to the temp string
string temp_str2 = "NAOMI";
cout << temp_str2 << endl;
temp_str2 = str_by_value(temp_str2);
cout << endl;
//Is the main created string the same variable(is it at the same memory address) as the returned 
//string why or why not?
//yes.  I referenced the same string.

string temp_str3 = "NAOMI";
cout << temp_str3 << endl;
//temp_str3 = const_str_by_reference(temp_str3);  //this will fail
cout << endl;
//Why does the compiler let you change or not let you change the incoming const reference parameter?
//because the referenced string is a constant


Line line;
Shape& shape = line;
shape.draw();
Circle c;
Shape& shape_c = c;
shape_c.draw();
//What will the output be for line.draw() and shape_c.draw()? Explain the rationale for the output.
//from the earlier example:  "Draw a Line Draw a circle"  draw() in shape is a virtual void, so Circle and Line pass through.


return 0;
}
