#include "receipt.h"
#include <iostream>

using namespace::std;
#include "receipt.h"
#include <iostream>

ostream & operator<<(ostream& out, const Receipt& r)
{
	out << "Bill Amount : " << r.bill_amount
		<< "Tip Amount : " << r.tip_amount
		<< "Tax Amount : " << r.tax_amount
		<< "Total Amount : " << r.total_amount;
	return out;
}

istream & operator>>(istream& in, Receipt& r)
{
	std::cout << "Enter bill amount: ";
	in >> r.bill_amount;
	return in;
}

Receipt operator += (const Receipt& r1, const Receipt& r2)
{
	Receipt temp_r(0.0);
	temp_r.bill_amount += r1.bill_amount;
	temp_r.tip_amount += r1.tip_amount;
	temp_r.tax_amount += r1.tax_amount;
	temp_r.total_amount += r1.total_amount;

	temp_r.bill_amount += r2.bill_amount;
	temp_r.tip_amount += r2.tip_amount;
	temp_r.tax_amount += r2.tax_amount;
	temp_r.total_amount += r2.total_amount;
	return temp_r;
}

double Receipt::get_tax_amount()
{
	double temp{ 0.0 };
	temp = bill_amount * 0.0825;
	return temp;
}

double Receipt::get_tip_amount()
{
	double temp{ 0.0 };
	temp = (bill_amount + tax_amount) * .15;
	return temp;
}


double Receipt::get_total_amount()
{
	double temp{ 0.0 };
	temp = tip_amount + tax_amount + bill_amount;
	return temp;
}
