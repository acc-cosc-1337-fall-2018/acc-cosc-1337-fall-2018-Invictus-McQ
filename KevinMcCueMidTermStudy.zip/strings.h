#include <iostream>
#include <string>
#include <vector>

using namespace::std;


//Given: A DNA string s.
	//Return : vector of Four integers counting the respective number of times that the symbols 
	//'A', 'C', 'G', and 'T' occur in s.


vector<int> count_symbols(const string s);


void str_by_reference(string& s);

string& str_by_value(string& s);

string& const_str_by_reference(const string& s);