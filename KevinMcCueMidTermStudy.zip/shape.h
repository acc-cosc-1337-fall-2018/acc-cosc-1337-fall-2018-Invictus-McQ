#pragma once
#include <iostream>
#include <vector>

#ifndef SHAPE_H
#define SHAPE_H

class Shape
{
public:
	virtual	void draw() { std::cout << "Draw a Shape\n"; }
};

#endif //SHAPE_H

#ifndef LINE_H
#define LINE_H
class Line : public Shape
{
public:
	void draw() { std::cout << "Draw a Line\n"; }
};

#endif //LINE_H

#ifndef CIRCLE_H
#define CIRCLE_H
class Circle : public Shape
{
public:
	void draw() { std::cout << "Draw a Circle\n"; }

};
#endif //CIRCLE_H

