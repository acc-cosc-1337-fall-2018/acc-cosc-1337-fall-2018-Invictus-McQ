#define CATCH_CONFIG_MAIN
/*

#include "catch.hpp"
#include "strings.h"
#include <vector>
#include <string>

using namespace::std;

TEST_CASE("Test count_symbols()")
{
	string const str = "AGCTTTTCATTCTGACTGCAACGGGCAATATGTCTCTGTGTGGATTAAAAAAAGAGTGTCTGATAGCAGC";

	REQUIRE(count_symbols(str)[0]) == 20);
	REQUIRE(count_symbols(str)[1]) == 12);
	REQUIRE(count_symbols(str)[2]) == 17);
	REQUIRE(count_symbols(str)[3]) == 21);
}



*/

