#pragma once
#include <vector>

using namespace::std;

void display_grades(vector<int> v);
