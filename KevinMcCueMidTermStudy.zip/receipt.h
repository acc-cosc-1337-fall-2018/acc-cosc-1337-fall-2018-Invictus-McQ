#ifndef RECEIPT_H
#define RECEIPT_H
#include <iostream>

using namespace::std;

class Receipt
{
public:
	Receipt() = default;
	Receipt(double b) : bill_amount(b) {};
	double get_tax_amount();
	double get_tip_amount();
	double get_total_amount();
	friend ostream & operator << (ostream& out, const Receipt& r);
	friend istream & operator >> (istream& in, Receipt& r);
	friend Receipt operator += (const Receipt& r1, const Receipt& r2);


private:
	double bill_amount{ 0.0 };
	double tip_amount = get_tip_amount();
	double tax_amount = get_tax_amount();
	double total_amount = get_total_amount();

};

#endif //RECEIPT_H
