#include "strings.h"
#include <vector>
#include <string>


vector<int> count_symbols(const string s)
{
	
	vector<int> ACGT_count = { 0,0,0,0 };
	for (auto i: s)
	{
		if (i == 'A') {
			ACGT_count[0] += 1;
		}
		else if (i == 'C') {
			ACGT_count[1] += 1;
		}
		else if (i == 'G') {
			ACGT_count[2] += 1;
		}
		else if (i == 'T') {
			ACGT_count[3] += 1;
		}

	}
	
	return ACGT_count;
}

void str_by_reference(string& s)
{

	string temp;
	int size = s.size();
		for (int i = size; i >= 0; --i) {
			temp += s[i];
		}
		s = temp;
		cout << s;

}

string& str_by_value(string& s)
{
	string temp;
	int size = s.size();
	for (int i = size; i >= 0; --i) {
		temp += s[i];
	}
	s = temp;
	return temp;
}

string& const_str_by_reference(const string& s)
{
	string temp;
	int size = s.size();
	for (int i = size; i >= 0; --i) {
		temp += s[i];
	}
	return temp;
}
