#include "vector.h"
#include <vector>
#include <iostream>

using namespace::std;


void display_grades(vector<int> v)
{
	int num_A{ 0 };
	int num_B{ 0 };
	int num_C{ 0 };
	int num_D{ 0 };
	int num_F{ 0 };

	for (auto n : v) {
		if (n >= 90) {
			num_A += 1;
		}
		else if (n >= 80) {
			num_B += 1;
		}
		else if (n >= 70) {
			num_C += 1;
		}
		else if (n >= 60) {
			num_D += 1;
		}
		else if (n >= 0) {
			num_F += 1;
		}
	}
	cout << "Grade" << "         Count of Each" << endl;
	cout << "A >= 90" << "           " << num_A << endl;
	cout << "B >= 80" << "           " << num_B << endl;
	cout << "C >= 70" << "           " << num_C << endl;
	cout << "D >= 60" << "           " << num_D << endl;
	cout << "F >= 0" << "            " << num_F << endl;
}
